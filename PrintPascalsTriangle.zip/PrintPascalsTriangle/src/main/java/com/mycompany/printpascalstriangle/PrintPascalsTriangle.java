/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.printpascalstriangle;
import java.util.Scanner;
/**
 *
 * @author Lenovo-User
 */
public class PrintPascalsTriangle {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of rows for Pascal's triangle: ");
        int numRows = scanner.nextInt();
        scanner.close();

        printPascalsTriangle(numRows);
    }

    // Function to print Pascal's triangle up to numRows rows
    public static void printPascalsTriangle(int numRows) {
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(binomialCoefficient(i, j) + " ");
            }
            System.out.println();
        }
    }

    // Function to calculate binomial coefficient (n choose k)
    public static int binomialCoefficient(int n, int k) {
        return factorial(n) / (factorial(k) * factorial(n - k));
    }

    // Function to calculate factorial of a number
    public static int factorial(int n) {
        if (n == 0)
            return 1;
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}
